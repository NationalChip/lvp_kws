-make whitout vui source code-
cp libvui.a lib
cp vuiconf.h include/vui
cp .config .config
make novuiconfig # do not edit this: Sram kept for NPU (KBytes)
mv lvp/vui/ .
make clean;make
mv vui/ lvp/
